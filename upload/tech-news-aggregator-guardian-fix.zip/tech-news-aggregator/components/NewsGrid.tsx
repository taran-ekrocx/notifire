// components/NewsGrid.tsx
'use client';

import { useState, useEffect, useCallback } from 'react';
import { Article } from '@/lib/types';
import { NewsCard } from './NewsCard';
import { CategoryFilter } from './CategoryFilter';
import { ArticleModal } from './ArticleModal';

export function NewsGrid() {
  const [rssArticles, setRssArticles]   = useState<Article[]>([]);
  const [aiArticles, setAiArticles]     = useState<Article[]>([]);
  const [category, setCategory]         = useState('all');
  const [activeTab, setActiveTab]       = useState<'rss' | 'ai'>('rss');
  const [rssLoading, setRssLoading]     = useState(true);
  const [aiLoading, setAiLoading]       = useState(false);
  const [rssError, setRssError]         = useState<string | null>(null);
  const [aiError, setAiError]           = useState<string | null>(null);
  const [cacheHit, setCacheHit]         = useState(false);
  const [lastUpdated, setLastUpdated]   = useState<Date | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const loadRSS = useCallback(async (cat: string) => {
    setRssLoading(true);
    setRssError(null);
    try {
      const res = await fetch(`/api/news?category=${cat}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: Article[] = await res.json();
      setRssArticles(data);
      setCacheHit(res.headers.get('X-Cache') === 'HIT');
      setLastUpdated(new Date());
    } catch (e) {
      setRssError(e instanceof Error ? e.message : 'Unknown error');
    } finally {
      setRssLoading(false);
    }
  }, []);

  const loadAI = useCallback(async (cat: string) => {
    setAiLoading(true);
    setAiError(null);
    try {
      const res = await fetch(`/api/ai-news?category=${cat}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: Article[] = await res.json();
      setAiArticles(data);
    } catch (e) {
      setAiError(e instanceof Error ? e.message : 'Unknown error');
    } finally {
      setAiLoading(false);
    }
  }, []);

  useEffect(() => { loadRSS(category); }, [category, loadRSS]);

  const handleTabChange = (tab: 'rss' | 'ai') => {
    setActiveTab(tab);
    if (tab === 'ai' && aiArticles.length === 0 && !aiLoading) {
      loadAI(category);
    }
  };

  const handleCategoryChange = (cat: string) => {
    setCategory(cat);
    setAiArticles([]);
    if (activeTab === 'ai') loadAI(cat);
  };

  const articles  = activeTab === 'rss' ? rssArticles : aiArticles;
  const isLoading = activeTab === 'rss' ? rssLoading  : aiLoading;
  const error     = activeTab === 'rss' ? rssError    : aiError;

  return (
    <div>
      <CategoryFilter active={category} onChange={handleCategoryChange} />

      <div className="source-tabs">
        <button
          className={`source-tab ${activeTab === 'rss' ? 'active' : ''}`}
          onClick={() => handleTabChange('rss')}
        >
          📡 RSS Feeds
          <span className="tab-count">{rssArticles.length}</span>
        </button>
        <button
          className={`source-tab ${activeTab === 'ai' ? 'active' : ''}`}
          onClick={() => handleTabChange('ai')}
        >
          ⚡ Live AI News
          {aiLoading
            ? <span className="tab-count">…</span>
            : <span className="tab-count">{aiArticles.length}</span>
          }
        </button>
      </div>

      <div className="status-bar">
        {activeTab === 'rss' && lastUpdated && (
          <span className="status-text">
            {cacheHit ? '⚡ Cached' : '🔄 Live RSS'} · {lastUpdated.toLocaleTimeString()}
          </span>
        )}
        {activeTab === 'ai' && (
          <span className="status-text">🤖 Claude + web search · up-to-date results</span>
        )}
        <button
          className="refresh-btn"
          onClick={() => activeTab === 'rss' ? loadRSS(category) : loadAI(category)}
          disabled={isLoading}
        >
          {isLoading ? 'Loading…' : '↻ Refresh'}
        </button>
      </div>

      {error && <div className="error-box">⚠️ Failed to load: {error}</div>}

      {activeTab === 'ai' && !aiLoading && aiArticles.length === 0 && !aiError && (
        <div className="ai-hint">
          Click <strong>↻ Refresh</strong> to fetch AI-powered live news from the web.
        </div>
      )}

      {isLoading && !articles.length ? (
        <div className="skeleton-grid">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="skeleton-card" />
          ))}
        </div>
      ) : (
        <div className="news-grid">
          {articles.map(a => (
            <NewsCard
              key={a.id || a.url}
              article={a}
              isAI={activeTab === 'ai'}
              onClick={setSelectedArticle}
            />
          ))}
          {!isLoading && articles.length === 0 && (
            <p className="empty">No articles found. Try refreshing.</p>
          )}
        </div>
      )}

      {selectedArticle && (
        <ArticleModal
          article={selectedArticle}
          onClose={() => setSelectedArticle(null)}
        />
      )}
    </div>
  );
}
