// components/ArticleModal.tsx
'use client';

import { useEffect, useState } from 'react';
import { Article, ArticleDetail } from '@/lib/types';

const SENTIMENT_CONFIG = {
  positive: { label: '↑ Positive', color: '#10b981' },
  neutral:  { label: '→ Neutral',  color: '#6b7280' },
  negative: { label: '↓ Negative', color: '#ef4444' },
};

const CATEGORY_COLORS: Record<string, string> = {
  ai: '#6366f1',
  cybersecurity: '#ef4444',
  databases: '#10b981',
  infrastructure: '#f59e0b',
};

const CATEGORY_ICONS: Record<string, string> = {
  ai: '🤖',
  cybersecurity: '🔐',
  databases: '🗄️',
  infrastructure: '⚙️',
};

export function ArticleModal({
  article,
  onClose,
}: {
  article: Article;
  onClose: () => void;
}) {
  const [detail, setDetail] = useState<ArticleDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const color = CATEGORY_COLORS[article.category] ?? '#6366f1';

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    const controller = new AbortController();

    fetch('/api/detail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: article.title,
        url: article.url,
        description: article.description,
        source: article.source,
      }),
      signal: controller.signal,
    })
      .then(r => r.json())
      .then(d => setDetail(d))
      .catch(() => {})
      .finally(() => setLoading(false));

    return () => {
      document.body.style.overflow = '';
      controller.abort();
    };
  }, [article]);

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const timeAgo = (iso: string) => {
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins} minutes ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs} hours ago`;
    return `${Math.floor(hrs / 24)} days ago`;
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>

        {/* Header stripe */}
        <div className="modal-stripe" style={{ background: color }} />

        {/* Close button */}
        <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>

        <div className="modal-body">
          {/* Meta */}
          <div className="modal-meta">
            <span className="modal-cat-badge" style={{ background: `${color}22`, color }}>
              {CATEGORY_ICONS[article.category]} {article.category}
            </span>
            <span className="modal-source">{article.source}</span>
            {article.author && <span className="modal-author">by {article.author}</span>}
            <span className="modal-time">{timeAgo(article.publishedAt)}</span>
          </div>

          {/* Title */}
          <h2 className="modal-title">{article.title}</h2>

          {/* AI Detail Section */}
          {loading ? (
            <div className="modal-loading">
              <div className="loading-spinner" />
              <span>Analyzing article with AI…</span>
            </div>
          ) : detail ? (
            <div className="modal-detail">

              {/* Read time + Sentiment */}
              <div className="modal-stats">
                <span className="stat-pill">📖 {detail.readTimeMinutes} min read</span>
                {detail.sentiment && (
                  <span
                    className="stat-pill"
                    style={{ color: SENTIMENT_CONFIG[detail.sentiment].color, borderColor: `${SENTIMENT_CONFIG[detail.sentiment].color}44` }}
                  >
                    {SENTIMENT_CONFIG[detail.sentiment].label}
                  </span>
                )}
              </div>

              {/* Full Summary */}
              <div className="modal-section">
                <h3 className="section-label">Summary</h3>
                <p className="modal-summary">{detail.fullSummary}</p>
              </div>

              {/* Key Points */}
              {detail.keyPoints?.length > 0 && (
                <div className="modal-section">
                  <h3 className="section-label">Key Points</h3>
                  <ul className="key-points">
                    {detail.keyPoints.map((pt, i) => (
                      <li key={i} className="key-point">
                        <span className="kp-dot" style={{ background: color }} />
                        {pt}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Related Topics */}
              {detail.relatedTopics?.length > 0 && (
                <div className="modal-section">
                  <h3 className="section-label">Related Topics</h3>
                  <div className="topics-row">
                    {detail.relatedTopics.map((t, i) => (
                      <span key={i} className="topic-tag">{t}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Fallback: just show description */
            <div className="modal-section">
              <p className="modal-summary">{article.description}</p>
            </div>
          )}

          {/* CTA */}
          <a
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="modal-cta"
            style={{ background: color }}
          >
            Read Full Article ↗
          </a>
        </div>
      </div>
    </div>
  );
}
