// components/CategoryFilter.tsx
'use client';

const TABS = [
  { value: 'all', label: '🌐 All' },
  { value: 'ai', label: '🤖 AI' },
  { value: 'cybersecurity', label: '🔐 Cyber' },
  { value: 'databases', label: '🗄️ Databases' },
  { value: 'infrastructure', label: '⚙️ Infra' },
];

export function CategoryFilter({
  active,
  onChange,
}: {
  active: string;
  onChange: (cat: string) => void;
}) {
  return (
    <div className="filter-bar">
      {TABS.map(tab => (
        <button
          key={tab.value}
          className={`filter-btn ${active === tab.value ? 'active' : ''}`}
          onClick={() => onChange(tab.value)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
