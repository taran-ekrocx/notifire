// components/NewsCard.tsx
import { Article } from '@/lib/types';

const CATEGORY_COLORS: Record<string, string> = {
  ai: '#6366f1',
  cybersecurity: '#ef4444',
  databases: '#10b981',
  infrastructure: '#f59e0b',
};

const CATEGORY_ICONS: Record<string, string> = {
  ai: '🤖',
  cybersecurity: '🔐',
  databases: '🗄️',
  infrastructure: '⚙️',
};

export function NewsCard({
  article,
  isAI = false,
  onClick,
}: {
  article: Article;
  isAI?: boolean;
  onClick: (article: Article) => void;
}) {
  const color = CATEGORY_COLORS[article.category] ?? '#6366f1';
  const icon = CATEGORY_ICONS[article.category] ?? '📰';
  const ago = timeAgo(article.publishedAt);

  return (
    <div className="news-card" onClick={() => onClick(article)} role="button" tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && onClick(article)}>
      <div className="card-accent" style={{ background: color }} />
      <div className="card-body">
        <div className="card-meta">
          <span className="cat-badge" style={{ background: `${color}22`, color }}>
            {icon} {article.category}
          </span>
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            {isAI && <span className="ai-badge">⚡ Live AI</span>}
            <span className="time-ago">{ago}</span>
          </div>
        </div>
        <h3 className="card-title">{article.title}</h3>
        {article.description && (
          <p className="card-desc">{article.description}</p>
        )}
        <div className="card-footer">
          <span className="source">{article.source}</span>
          {article.author && <span className="author">by {article.author}</span>}
          <span className="read-more">Click for details →</span>
        </div>
      </div>
    </div>
  );
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}
