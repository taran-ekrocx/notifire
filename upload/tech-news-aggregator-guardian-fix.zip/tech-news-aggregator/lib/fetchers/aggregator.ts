// lib/fetchers/aggregator.ts
import { Article, Category } from '../types';
import { fetchRSSFeeds } from './rss';
import { fetchGuardian } from './guardian';
import { RSS_SOURCES } from '../config/rss-sources';
import { deduplicate } from '../processors/deduplicator';

const CATEGORIES: Category[] = ['ai', 'cybersecurity', 'databases', 'infrastructure'];

/**
 * Fetch articles for a specific category or all categories.
 * RSS and Guardian are fetched in parallel per category.
 * Guardian articles are merged in and deduplicated alongside RSS.
 */
export async function fetchAllSources(categoryParam: string): Promise<Article[]> {
  const targets: Category[] =
    categoryParam === 'all'
      ? CATEGORIES
      : CATEGORIES.includes(categoryParam as Category)
        ? [categoryParam as Category]
        : CATEGORIES;

  // For each category, fetch RSS and Guardian in parallel
  const settled = await Promise.allSettled(
    targets.flatMap(cat => [
      fetchRSSFeeds(RSS_SOURCES[cat], cat, 6),
      fetchGuardian(cat, 5),
    ])
  );

  const all: Article[] = [];
  for (const result of settled) {
    if (result.status === 'fulfilled') {
      all.push(...result.value);
    }
  }

  return deduplicate(all).sort(
    (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );
}
