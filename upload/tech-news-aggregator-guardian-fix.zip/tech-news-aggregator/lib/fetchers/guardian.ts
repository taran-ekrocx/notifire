// lib/fetchers/guardian.ts
import { Article, Category } from '../types';
import { detectCategory } from '../processors/categoryTagger';

const GUARDIAN_BASE = 'https://content.guardianapis.com/search';

// Strict keyword queries per category
const GUARDIAN_QUERIES: Record<Category, string> = {
  ai:             'artificial intelligence OR machine learning OR LLM OR GPT OR neural network OR generative AI',
  cybersecurity:  'cybersecurity OR ransomware OR malware OR data breach OR vulnerability OR hacking OR CVE',
  databases:      'database OR PostgreSQL OR MongoDB OR Redis OR MySQL OR SQL OR vector database OR Snowflake',
  infrastructure: 'Kubernetes OR DevOps OR cloud computing OR serverless OR Docker OR Terraform OR microservices OR AWS OR Azure',
};

// Individual keywords per category used to hard-filter results
const CATEGORY_KEYWORDS: Record<Category, string[]> = {
  ai:             ['artificial intelligence', 'machine learning', 'llm', 'gpt', 'neural network', 'generative ai', 'openai', 'anthropic', 'chatgpt', 'deep learning'],
  cybersecurity:  ['cybersecurity', 'ransomware', 'malware', 'data breach', 'vulnerability', 'hacking', 'cve', 'cyber attack', 'phishing', 'exploit'],
  databases:      ['database', 'postgresql', 'mongodb', 'redis', 'mysql', 'sql', 'vector database', 'snowflake', 'nosql', 'data warehouse'],
  infrastructure: ['kubernetes', 'devops', 'cloud computing', 'serverless', 'docker', 'terraform', 'microservices', 'aws', 'azure', 'google cloud'],
};

interface GuardianFields {
  trailText?: string;
  thumbnail?: string;
  byline?:    string;
}

interface GuardianResult {
  id:                 string;
  webTitle:           string;
  webUrl:             string;
  webPublicationDate: string;
  sectionName:        string;
  fields?:            GuardianFields;
}

interface GuardianResponse {
  response: {
    status:  string;
    results: GuardianResult[];
  };
}

function isRelevant(item: GuardianResult, category: Category): boolean {
  const text = `${item.webTitle} ${item.fields?.trailText ?? ''}`.toLowerCase();
  return CATEGORY_KEYWORDS[category].some(kw => text.includes(kw));
}

function normalizeGuardianArticle(item: GuardianResult, forcedCategory: Category): Article {
  const text     = `${item.webTitle} ${item.fields?.trailText ?? ''}`;
  const detected = detectCategory(text);

  return {
    id:          '',
    title:       item.webTitle,
    url:         item.webUrl,
    description: (item.fields?.trailText ?? '').slice(0, 300).trim(),
    publishedAt: item.webPublicationDate,
    source:      'The Guardian',
    imageUrl:    item.fields?.thumbnail,
    author:      item.fields?.byline,
    category:    detected ?? forcedCategory,
  };
}

function recentDate(): string {
  const d = new Date(Date.now() - 48 * 60 * 60 * 1000);
  return d.toISOString().split('T')[0];
}

export async function fetchGuardian(category: Category, limit = 5): Promise<Article[]> {
  const apiKey = process.env.GUARDIAN_API_KEY;

  if (!apiKey) {
    console.warn('[Guardian] GUARDIAN_API_KEY not set — skipping');
    return [];
  }

  const params = new URLSearchParams({
    q:             GUARDIAN_QUERIES[category],
    section:       'technology',
    'show-fields': 'trailText,thumbnail,byline',
    'page-size':   String(limit),
    'order-by':    'newest',
    'from-date':   recentDate(),
    'api-key':     apiKey,
  });

  try {
    const res = await fetch(`${GUARDIAN_BASE}?${params}`, {
      next: { revalidate: 900 },
    });

    if (!res.ok) {
      console.warn(`[Guardian] HTTP ${res.status} for category "${category}"`);
      return [];
    }

    const data: GuardianResponse = await res.json();

    if (data.response.status !== 'ok') {
      console.warn('[Guardian] Non-ok status:', data.response.status);
      return [];
    }

    // Hard filter — drop anything that doesn't mention our keywords
    const relevant = data.response.results.filter(item => isRelevant(item, category));

    if (relevant.length === 0) {
      console.info(`[Guardian] No relevant results for "${category}"`);
      return [];
    }

    return relevant.map(item => normalizeGuardianArticle(item, category));
  } catch (err) {
    console.error(`[Guardian] Fetch failed for "${category}":`, err);
    return [];
  }
}
