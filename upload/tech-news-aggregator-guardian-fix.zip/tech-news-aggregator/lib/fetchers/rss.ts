// lib/fetchers/rss.ts
import Parser from 'rss-parser';
import { Article, Category } from '../types';
import { detectCategory } from '../processors/categoryTagger';

type CustomItem = {
  title?: string;
  link?: string;
  contentSnippet?: string;
  summary?: string;
  pubDate?: string;
  isoDate?: string;
  creator?: string;
  'media:content'?: { $: { url: string } };
  'media:thumbnail'?: { $: { url: string } };
  enclosure?: { url?: string };
};

type CustomFeed = {
  title?: string;
  items: CustomItem[];
};

const parser = new Parser<CustomFeed, CustomItem>({
  timeout: 8000,
  headers: { 'User-Agent': 'TechNewsBot/1.0 (RSS Aggregator)' },
  customFields: {
    item: ['media:content', 'media:thumbnail', 'enclosure'],
  },
});

/**
 * Fetch articles from a list of RSS feed URLs.
 * @param urls      - Array of RSS/Atom feed URLs
 * @param category  - The category these feeds belong to (used as fallback tag)
 * @param limit     - Max articles to pull per feed (default 5)
 */
export async function fetchRSSFeeds(
  urls: string[],
  category: Category,
  limit = 5
): Promise<Article[]> {
  const results = await Promise.allSettled(
    urls.map(url => parser.parseURL(url))
  );

  const articles: Article[] = [];

  for (let i = 0; i < results.length; i++) {
    const result = results[i];
    const feedUrl = urls[i];

    if (result.status === 'rejected') {
      console.warn(`[RSS] Failed to fetch ${feedUrl}:`, result.reason?.message ?? result.reason);
      continue;
    }

    const feed = result.value;

    for (const item of feed.items.slice(0, limit)) {
      if (!item.title || !item.link) continue;

      const combinedText = `${item.title} ${item.contentSnippet ?? ''} ${item.summary ?? ''}`;
      const detectedCategory = detectCategory(combinedText) ?? category;

      // Try to extract an image from multiple possible fields
      const imageUrl =
        item['media:content']?.$.url ??
        item['media:thumbnail']?.$.url ??
        item.enclosure?.url ??
        undefined;

      articles.push({
        id: '',                          // filled by deduplicator
        title: item.title.trim(),
        url: item.link,
        description: (item.contentSnippet ?? item.summary ?? '').slice(0, 300).trim(),
        publishedAt: item.isoDate ?? item.pubDate ?? new Date().toISOString(),
        source: feed.title ?? new URL(feedUrl).hostname,
        imageUrl,
        author: item.creator,
        category: detectedCategory,
      });
    }
  }

  return articles;
}
