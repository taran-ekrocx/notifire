// lib/config/rss-sources.ts
import { Category } from '../types';

export const RSS_SOURCES: Record<Category, string[]> = {
  ai: [
    'https://techcrunch.com/category/artificial-intelligence/feed/',
    'https://venturebeat.com/category/ai/feed/',
    'https://feeds.arstechnica.com/arstechnica/technology-lab',
    'https://www.technologyreview.com/feed/',
  ],
  cybersecurity: [
    'https://feeds.feedburner.com/TheHackersNews',
    'https://krebsonsecurity.com/feed/',
    'https://www.darkreading.com/rss.xml',
    'https://www.schneier.com/feed/atom/',
  ],
  databases: [
    'https://www.postgresql.org/news.rss',
    'https://thenewstack.io/feed/',
    'https://redis.io/blog/feed/',
  ],
  infrastructure: [
    'https://kubernetes.io/feed.xml',
    'https://devops.com/feed/',
    'https://thenewstack.io/feed/',
    'https://www.infoq.com/feed/',
  ],
};
