// lib/types.ts
export type Category = 'ai' | 'cybersecurity' | 'databases' | 'infrastructure';

export interface Article {
  id: string;
  title: string;
  url: string;
  description: string;
  publishedAt: string; // ISO 8601
  source: string;
  imageUrl?: string;
  author?: string;
  category: Category;
  tags?: string[];
  // Detail fields (populated on demand via AI)
  fullSummary?: string;
  keyPoints?: string[];
  readTimeMinutes?: number;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface ArticleDetail {
  fullSummary: string;
  keyPoints: string[];
  readTimeMinutes: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  relatedTopics: string[];
}
