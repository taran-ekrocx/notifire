// lib/processors/categoryTagger.ts
import { Category } from '../types';

const KEYWORDS: Record<Category, string[]> = {
  ai: [
    'artificial intelligence', 'machine learning', 'llm', 'gpt', 'neural',
    'openai', 'anthropic', 'gemini', 'deep learning', 'transformer', 'embedding', 'nlp',
    'chatgpt', 'large language model', 'generative ai', 'diffusion model',
  ],
  cybersecurity: [
    'ransomware', 'malware', 'vulnerability', 'breach', 'cve', 'zero-day',
    'phishing', 'siem', 'soc', 'threat', 'exploit', 'patch', 'firewall',
    'hacker', 'cybersecurity', 'infosec', 'security', 'attack', 'botnet',
  ],
  databases: [
    'postgresql', 'mysql', 'mongodb', 'redis', 'cassandra', 'sqlite', 'oracle',
    'database', 'vector db', 'sql', 'nosql', 'clickhouse', 'snowflake',
    'supabase', 'planetscale', 'turso', 'duckdb',
  ],
  infrastructure: [
    'kubernetes', 'docker', 'terraform', 'ansible', 'devops', 'ci/cd',
    'serverless', 'edge', 'cdn', 'load balancer', 'microservices',
    'helm', 'gitops', 'cloud', 'aws', 'azure', 'gcp', 'vercel',
  ],
};

export function detectCategory(text: string): Category {
  const lower = text.toLowerCase();
  const scores: Record<Category, number> = {
    ai: 0, cybersecurity: 0, databases: 0, infrastructure: 0,
  };

  for (const [cat, keywords] of Object.entries(KEYWORDS) as [Category, string[]][]) {
    scores[cat] = keywords.filter(kw => lower.includes(kw)).length;
  }

  const best = (Object.entries(scores) as [Category, number][])
    .sort((a, b) => b[1] - a[1])[0];

  return best[1] > 0 ? best[0] : 'infrastructure';
}
