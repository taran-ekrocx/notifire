// app/api/detail/route.ts
// Calls Claude with web_search to generate a rich article detail summary
import { NextRequest, NextResponse } from 'next/server';
import { ArticleDetail } from '@/lib/types';

const detailCache = new Map<string, { data: ArticleDetail; expiresAt: number }>();

function getCached(key: string): ArticleDetail | null {
  const e = detailCache.get(key);
  if (!e || Date.now() > e.expiresAt) { detailCache.delete(key); return null; }
  return e.data;
}

export async function POST(req: NextRequest) {
  const { title, url, description, source } = await req.json();
  if (!title || !url) {
    return NextResponse.json({ error: 'title and url required' }, { status: 400 });
  }

  const cacheKey = `detail:${url}`;
  const cached = getCached(cacheKey);
  if (cached) return NextResponse.json(cached, { headers: { 'X-Cache': 'HIT' } });

  const prompt = `You are a tech news analyst. Analyze this article and respond ONLY with a JSON object, no markdown, no backticks.

Article:
Title: ${title}
Source: ${source}
URL: ${url}
Description: ${description}

Respond with exactly this JSON structure:
{
  "fullSummary": "3-4 sentence detailed summary of what this article is about, its key findings, and why it matters to tech professionals",
  "keyPoints": ["point 1", "point 2", "point 3", "point 4"],
  "readTimeMinutes": 3,
  "sentiment": "positive",
  "relatedTopics": ["topic1", "topic2", "topic3"]
}

Rules:
- fullSummary: 3-4 sentences, informative and detailed
- keyPoints: exactly 4 bullet points, each under 15 words
- readTimeMinutes: integer 1-10
- sentiment: exactly one of "positive", "neutral", "negative"
- relatedTopics: exactly 3 short topic strings
- Use web search to find current details about this article if needed`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();

    // Extract the final text block (after any tool use)
    const textBlocks = data.content?.filter((b: { type: string }) => b.type === 'text') ?? [];
    const raw = textBlocks.map((b: { text: string }) => b.text).join('');

    // Strip any accidental markdown fences
    const clean = raw.replace(/```json|```/g, '').trim();
    const detail: ArticleDetail = JSON.parse(clean);

    // Cache for 1 hour
    detailCache.set(cacheKey, { data: detail, expiresAt: Date.now() + 3600_000 });

    return NextResponse.json(detail, { headers: { 'X-Cache': 'MISS' } });
  } catch (err) {
    console.error('[detail] Error:', err);
    // Fallback: use real description if available, skip generic bullets
    const fallback: ArticleDetail = {
      fullSummary: description
        ? `${description} Read the full article at ${source} for complete details.`
        : `This article from ${source} covers recent developments in tech. Visit the source for the full story.`,
      keyPoints: description
        ? [
            description.split('.')[0]?.trim() || 'Read the full article for details',
            `Published by ${source}`,
            'Click "Read Full Article" for the complete story',
            'AI summary temporarily unavailable — check back shortly',
          ]
        : [
            `Published by ${source}`,
            'Click "Read Full Article" for the complete story',
            'AI enrichment requires ANTHROPIC_API_KEY to be set',
            'See .env.local for setup instructions',
          ],
      readTimeMinutes: 3,
      sentiment: 'neutral',
      relatedTopics: ['Technology', 'Industry News', 'Latest Updates'],
    };
    return NextResponse.json(fallback);
  }
}
