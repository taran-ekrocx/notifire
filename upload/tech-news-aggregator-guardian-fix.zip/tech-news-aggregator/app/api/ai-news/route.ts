// app/api/ai-news/route.ts
// Uses Claude + web_search to find the very latest tech news
import { NextRequest, NextResponse } from 'next/server';
import { Article, Category } from '@/lib/types';
import { createHash } from 'crypto';

const aiCache = new Map<string, { data: Article[]; expiresAt: number }>();

function getCached(key: string): Article[] | null {
  const e = aiCache.get(key);
  if (!e || Date.now() > e.expiresAt) { aiCache.delete(key); return null; }
  return e.data;
}

const CATEGORY_QUERIES: Record<string, string> = {
  ai: 'latest artificial intelligence news today 2026 OpenAI Google Anthropic',
  cybersecurity: 'latest cybersecurity news today 2026 breach vulnerability exploit',
  databases: 'latest database technology news today 2026 PostgreSQL MongoDB cloud',
  infrastructure: 'latest cloud infrastructure devops kubernetes news today 2026',
  all: 'latest tech news today 2026 AI cybersecurity cloud infrastructure',
};

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get('category') ?? 'all';
  const cacheKey = `ai-news:${category}`;
  const cached = getCached(cacheKey);
  if (cached) return NextResponse.json(cached, { headers: { 'X-Cache': 'HIT' } });

  const query = CATEGORY_QUERIES[category] ?? CATEGORY_QUERIES.all;

  const prompt = `Search the web for the very latest tech news from today or this week. 
Query to search: "${query}"

After searching, respond ONLY with a JSON array of news articles. No markdown, no backticks, just raw JSON.

Return exactly this structure (array of 8 articles):
[
  {
    "title": "Article headline",
    "url": "https://actual-url.com/article",
    "description": "2-3 sentence summary of what happened and why it matters",
    "source": "Publication name",
    "publishedAt": "2026-05-11T10:00:00Z",
    "category": "${category === 'all' ? 'ai' : category}",
    "author": "Author name or empty string"
  }
]

Rules:
- Use REAL articles from your web search results
- publishedAt must be a valid ISO 8601 date string
- category must be one of: ai, cybersecurity, databases, infrastructure
- description should be 2-3 informative sentences
- Only return the JSON array, nothing else`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    const textBlocks = data.content?.filter((b: { type: string }) => b.type === 'text') ?? [];
    const raw = textBlocks.map((b: { text: string }) => b.text).join('');
    const clean = raw.replace(/```json|```/g, '').trim();

    const parsed = JSON.parse(clean);
    const articles: Article[] = parsed.map((a: Omit<Article, 'id'>) => ({
      ...a,
      id: createHash('sha256').update(a.url).digest('hex').slice(0, 12),
      category: (a.category as Category) ?? (category === 'all' ? 'ai' : category as Category),
    }));

    // Cache for 30 min (AI search is slower, cache longer)
    aiCache.set(cacheKey, { data: articles, expiresAt: Date.now() + 1800_000 });
    return NextResponse.json(articles, { headers: { 'X-Cache': 'MISS' } });
  } catch (err) {
    console.error('[ai-news] Error:', err);
    return NextResponse.json([], { status: 200 });
  }
}
