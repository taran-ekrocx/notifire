// app/api/news/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchAllSources } from '@/lib/fetchers/aggregator';

// ISR revalidation every 15 minutes
export const revalidate = 900;

// In-memory cache for local dev (no Redis needed)
const memCache = new Map<string, { data: unknown; expiresAt: number }>();

function getFromCache<T>(key: string): T | null {
  const entry = memCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    memCache.delete(key);
    return null;
  }
  return entry.data as T;
}

function setInCache(key: string, data: unknown, ttlSeconds: number) {
  memCache.set(key, { data, expiresAt: Date.now() + ttlSeconds * 1000 });
}

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get('category') ?? 'all';
  const cacheKey = `news:${category}`;

  // 1. Check in-memory cache
  const cached = getFromCache(cacheKey);
  if (cached) {
    return NextResponse.json(cached, {
      headers: { 'X-Cache': 'HIT' },
    });
  }

  try {
    // 2. Fetch live from RSS feeds
    const articles = await fetchAllSources(category);
    const sliced = articles.slice(0, 20);

    // 3. Store in cache (15 min TTL)
    setInCache(cacheKey, sliced, 900);

    return NextResponse.json(sliced, {
      headers: {
        'X-Cache': 'MISS',
        'Cache-Control': 'public, s-maxage=900, stale-while-revalidate=1800',
      },
    });
  } catch (error) {
    console.error('[API] Failed to fetch news:', error);
    return NextResponse.json({ error: 'Failed to fetch news' }, { status: 500 });
  }
}
