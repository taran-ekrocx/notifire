// app/page.tsx
import { NewsGrid } from '@/components/NewsGrid';

export default function Home() {
  return (
    <>
      <header className="header">
        <div>
          <div className="logo">Tech<span>Pulse</span></div>
        </div>
        <div className="header-sub">RSS-powered · No API key required</div>
      </header>
      <main className="main">
        <NewsGrid />
      </main>
    </>
  );
}
