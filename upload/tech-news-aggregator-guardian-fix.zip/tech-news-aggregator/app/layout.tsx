// app/layout.tsx
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'TechPulse — Tech News Aggregator',
  description: 'Real-time tech news across AI, Cybersecurity, Databases, and Infrastructure',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <style>{`
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

          :root {
            --bg: #0d0f14;
            --surface: #161922;
            --surface2: #1e2130;
            --border: #2a2f42;
            --text: #e8eaf0;
            --muted: #8890a8;
            --accent: #5b6af0;
            --radius: 10px;
            --font-mono: 'Space Mono', monospace;
            --font-sans: 'DM Sans', sans-serif;
          }

          body {
            background: var(--bg);
            color: var(--text);
            font-family: var(--font-sans);
            min-height: 100vh;
          }

          .header {
            border-bottom: 1px solid var(--border);
            padding: 20px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: var(--surface);
          }

          .logo {
            font-family: var(--font-mono);
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text);
            letter-spacing: -0.5px;
          }

          .logo span { color: var(--accent); }

          .header-sub {
            font-size: 0.78rem;
            color: var(--muted);
            font-family: var(--font-mono);
          }

          .main {
            max-width: 1300px;
            margin: 0 auto;
            padding: 32px 24px;
          }

          .filter-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
          }

          .filter-btn {
            font-family: var(--font-sans);
            font-size: 0.85rem;
            font-weight: 500;
            padding: 7px 16px;
            border-radius: 999px;
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--muted);
            cursor: pointer;
            transition: all 0.15s ease;
          }

          .filter-btn:hover { border-color: var(--accent); color: var(--text); }
          .filter-btn.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
          }

          .status-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            padding: 10px 0;
          }

          .status-text {
            font-family: var(--font-mono);
            font-size: 0.75rem;
            color: var(--muted);
          }

          .refresh-btn {
            font-family: var(--font-mono);
            font-size: 0.75rem;
            padding: 6px 14px;
            background: transparent;
            border: 1px solid var(--border);
            color: var(--muted);
            border-radius: var(--radius);
            cursor: pointer;
            transition: all 0.15s;
          }

          .refresh-btn:hover:not(:disabled) { border-color: var(--accent); color: var(--text); }
          .refresh-btn:disabled { opacity: 0.4; cursor: not-allowed; }

          .news-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 16px;
          }

          .news-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            display: flex;
            overflow: hidden;
            transition: transform 0.15s ease, border-color 0.15s ease;
          }

          .news-card:hover {
            transform: translateY(-2px);
            border-color: #3a3f58;
          }

          .card-accent {
            width: 4px;
            flex-shrink: 0;
          }

          .card-body {
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            flex: 1;
          }

          .card-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
          }

          .cat-badge {
            font-family: var(--font-mono);
            font-size: 0.7rem;
            font-weight: 700;
            padding: 3px 8px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }

          .time-ago {
            font-family: var(--font-mono);
            font-size: 0.7rem;
            color: var(--muted);
          }

          .card-title {
            font-size: 0.95rem;
            font-weight: 600;
            line-height: 1.45;
            color: var(--text);
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }

          .card-desc {
            font-size: 0.82rem;
            color: var(--muted);
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }

          .card-footer {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: auto;
            padding-top: 6px;
          }

          .source {
            font-family: var(--font-mono);
            font-size: 0.7rem;
            color: var(--muted);
            background: var(--surface2);
            padding: 2px 7px;
            border-radius: 4px;
          }

          .author {
            font-size: 0.72rem;
            color: var(--muted);
          }

          .skeleton-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 16px;
          }

          @keyframes shimmer {
            0% { background-position: -600px 0; }
            100% { background-position: 600px 0; }
          }

          .skeleton-card {
            height: 160px;
            border-radius: var(--radius);
            background: linear-gradient(90deg, var(--surface) 25%, var(--surface2) 50%, var(--surface) 75%);
            background-size: 600px 100%;
            animation: shimmer 1.4s infinite linear;
          }

          .error-box {
            background: #2a1515;
            border: 1px solid #5a2020;
            color: #f87171;
            padding: 14px 18px;
            border-radius: var(--radius);
            font-size: 0.85rem;
            margin-bottom: 20px;
          }

          .empty {
            color: var(--muted);
            font-size: 0.9rem;
            padding: 40px 0;
            grid-column: 1 / -1;
            text-align: center;
          }

          /* ── news card cursor ── */
          .news-card { cursor: pointer; }
          .read-more {
            margin-left: auto;
            font-family: var(--font-mono);
            font-size: 0.68rem;
            color: var(--accent);
            opacity: 0;
            transition: opacity 0.15s;
          }
          .news-card:hover .read-more { opacity: 1; }
          .ai-badge {
            font-family: var(--font-mono);
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 4px;
            background: #1a1a3a;
            color: #818cf8;
            border: 1px solid #3730a3;
          }
          .source-tabs { display: flex; gap: 8px; margin-bottom: 16px; }
          .source-tab {
            display: flex; align-items: center; gap: 8px;
            font-family: var(--font-sans); font-size: 0.85rem; font-weight: 500;
            padding: 8px 18px; border-radius: var(--radius);
            border: 1px solid var(--border); background: var(--surface);
            color: var(--muted); cursor: pointer; transition: all 0.15s;
          }
          .source-tab:hover { border-color: var(--accent); color: var(--text); }
          .source-tab.active { background: var(--surface2); border-color: var(--accent); color: var(--text); }
          .tab-count {
            font-family: var(--font-mono); font-size: 0.7rem;
            background: var(--surface2); padding: 2px 7px; border-radius: 99px; color: var(--muted);
          }
          .source-tab.active .tab-count { background: var(--bg); }
          .ai-hint {
            background: #0f1a2e; border: 1px solid #1e3a5f; color: #93c5fd;
            padding: 14px 18px; border-radius: var(--radius); font-size: 0.85rem; margin-bottom: 20px;
          }
          .modal-backdrop {
            position: fixed; inset: 0; background: rgba(0,0,0,0.75);
            backdrop-filter: blur(4px); z-index: 1000;
            display: flex; align-items: center; justify-content: center;
            padding: 20px; animation: fadeIn 0.15s ease;
          }
          @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
          @keyframes slideUp { from { transform: translateY(24px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
          .modal-box {
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 14px; width: 100%; max-width: 640px;
            max-height: 88vh; overflow-y: auto; position: relative;
            animation: slideUp 0.2s ease;
          }
          .modal-stripe { height: 5px; border-radius: 14px 14px 0 0; }
          .modal-close {
            position: sticky; top: 12px; float: right; margin: 12px 16px 0 0;
            background: var(--surface2); border: 1px solid var(--border);
            color: var(--muted); width: 30px; height: 30px; border-radius: 50%;
            font-size: 0.75rem; cursor: pointer; display: flex;
            align-items: center; justify-content: center; transition: all 0.15s; z-index: 10;
          }
          .modal-close:hover { background: var(--border); color: var(--text); }
          .modal-body { padding: 20px 28px 28px; clear: both; }
          .modal-meta { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 14px; }
          .modal-cat-badge {
            font-family: var(--font-mono); font-size: 0.7rem; font-weight: 700;
            padding: 3px 8px; border-radius: 4px; text-transform: uppercase;
          }
          .modal-source {
            font-family: var(--font-mono); font-size: 0.72rem; color: var(--muted);
            background: var(--surface2); padding: 2px 8px; border-radius: 4px;
          }
          .modal-author { font-size: 0.78rem; color: var(--muted); }
          .modal-time { font-family: var(--font-mono); font-size: 0.7rem; color: var(--muted); margin-left: auto; }
          .modal-title { font-size: 1.2rem; font-weight: 700; line-height: 1.4; color: var(--text); margin-bottom: 18px; }
          .modal-loading { display: flex; align-items: center; gap: 12px; padding: 20px 0; color: var(--muted); font-size: 0.85rem; }
          @keyframes spin { to { transform: rotate(360deg); } }
          .loading-spinner {
            width: 18px; height: 18px; border: 2px solid var(--border);
            border-top-color: var(--accent); border-radius: 50%;
            animation: spin 0.7s linear infinite; flex-shrink: 0;
          }
          .modal-stats { display: flex; gap: 10px; margin-bottom: 18px; }
          .stat-pill {
            font-family: var(--font-mono); font-size: 0.72rem;
            padding: 4px 10px; border: 1px solid var(--border); border-radius: 99px; color: var(--muted);
          }
          .modal-section { margin-bottom: 18px; }
          .section-label {
            font-family: var(--font-mono); font-size: 0.65rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px; color: var(--muted); margin-bottom: 8px;
          }
          .modal-summary { font-size: 0.92rem; line-height: 1.7; color: var(--text); }
          .key-points { list-style: none; display: flex; flex-direction: column; gap: 8px; }
          .key-point { display: flex; align-items: flex-start; gap: 10px; font-size: 0.88rem; color: var(--text); line-height: 1.5; }
          .kp-dot { width: 7px; height: 7px; border-radius: 50%; margin-top: 6px; flex-shrink: 0; }
          .topics-row { display: flex; flex-wrap: wrap; gap: 8px; }
          .topic-tag { font-size: 0.78rem; padding: 4px 12px; background: var(--surface2); border: 1px solid var(--border); border-radius: 99px; color: var(--muted); }
          .modal-cta {
            display: inline-block; margin-top: 8px; padding: 10px 22px;
            border-radius: 8px; color: #fff; font-weight: 600; font-size: 0.88rem;
            text-decoration: none; transition: opacity 0.15s;
          }
          .modal-cta:hover { opacity: 0.85; }
          @media (max-width: 640px) {
            .header { padding: 16px; }
            .main { padding: 20px 16px; }
            .news-grid, .skeleton-grid { grid-template-columns: 1fr; }
            .modal-box { max-height: 92vh; }
            .modal-body { padding: 16px 18px 24px; }
            .modal-title { font-size: 1rem; }
          }
        `}</style>
        {children}
      </body>
    </html>
  );
}
